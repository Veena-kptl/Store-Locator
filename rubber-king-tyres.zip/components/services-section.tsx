import { Card, CardContent } from "@/components/ui/card"
import { Truck, Shield, Zap, Wrench } from "lucide-react"

const services = [
  {
    icon: Truck,
    title: "PAN India Free Delivery",
    description: "Free delivery across India for all our products with reliable logistics partners",
  },
  {
    icon: Shield,
    title: "Quality Warranty",
    description: "Comprehensive warranty coverage on all products ensuring peace of mind",
  },
  {
    icon: Zap,
    title: "Faster Claim Process",
    description: "Quick and efficient claim processing for warranty and service requests",
  },
  {
    icon: Wrench,
    title: "Free AMC*",
    description: "Complimentary Annual Maintenance Contract for eligible products",
  },
]

export function ServicesSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-balance mb-4">Why Choose Rubber King?</h2>
          <p className="text-xl text-muted-foreground text-balance max-w-2xl mx-auto">
            We provide comprehensive services to ensure the best experience for our customers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card key={service.title} className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 mx-auto mb-6 bg-primary/10 rounded-full flex items-center justify-center">
                  <service.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-4">{service.title}</h3>
                <p className="text-muted-foreground text-pretty">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
