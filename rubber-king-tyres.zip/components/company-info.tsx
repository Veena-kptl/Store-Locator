import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CompanyInfo() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-balance mb-6">About Rubber King Tyre Private Limited</h2>
            <p className="text-lg text-muted-foreground text-pretty mb-6">
              A flagship company of Gawarvala Group, a respected business family from Gujarat, India. Rubber King
              specializes in manufacturing its product range with 4 state-of-art manufacturing plants located in
              Gujarat.
            </p>
            <p className="text-lg text-muted-foreground text-pretty mb-8">
              We are leading manufacturers and exporters of Solid Cushion Tyres, Automotive Butyl Inner Tubes, Flaps and
              Tyre Curing Bladders, serving customers across India and globally.
            </p>
            <Button size="lg">
              Our Story
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
          <div className="relative">
            <img
              src="/modern-tire-manufacturing-facility.jpg"
              alt="Rubber King Manufacturing Facility"
              className="w-full h-auto rounded-lg shadow-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-lg" />
          </div>
        </div>
      </div>
    </section>
  )
}
