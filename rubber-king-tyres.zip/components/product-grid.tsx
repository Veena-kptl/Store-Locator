"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Eye } from "lucide-react"
import Link from "next/link"

const products = [
  {
    id: "dunamis",
    name: "Dunamis",
    category: "Solid Tyres",
    description: "High-performance solid tyres for heavy-duty applications",
    image: "/dunamis-solid-tire.jpg",
    price: "Contact for pricing",
    inStock: true,
    featured: true,
  },
  {
    id: "solitrek",
    name: "Solitrek",
    category: "Solid Tyres",
    description: "Durable solid tyres for industrial equipment",
    image: "/solitrek-solid-tire.jpg",
    price: "Contact for pricing",
    inStock: true,
    featured: false,
  },
  {
    id: "solidwings",
    name: "Solidwings",
    category: "Solid Tyres",
    description: "Premium solid tyres for material handling",
    image: "/solidwings-solid-tire.jpg",
    price: "Contact for pricing",
    inStock: true,
    featured: true,
  },
  {
    id: "rocksolid",
    name: "Rocksolid",
    category: "Solid Tyres",
    description: "Ultra-durable tyres for extreme conditions",
    image: "/rocksolid-solid-tire.jpg",
    price: "Contact for pricing",
    inStock: true,
    featured: false,
  },
  {
    id: "goliath",
    name: "Goliath",
    category: "Solid Tyres",
    description: "Heavy-duty tyres for maximum load capacity",
    image: "/goliath-solid-tire.jpg",
    price: "Contact for pricing",
    inStock: true,
    featured: true,
  },
  {
    id: "inner-tubes",
    name: "Inner Tubes",
    category: "Tubes & Flaps",
    description: "High-quality butyl inner tubes for various applications",
    image: "/inner-tubes.jpg",
    price: "Contact for pricing",
    inStock: true,
    featured: false,
  },
  {
    id: "flaps",
    name: "Flaps",
    category: "Tubes & Flaps",
    description: "Durable rubber flaps for tube protection",
    image: "/rubber-flaps.jpg",
    price: "Contact for pricing",
    inStock: true,
    featured: false,
  },
  {
    id: "bladders",
    name: "Curing Bladders",
    category: "Bladders",
    description: "Premium tyre curing bladders for manufacturing",
    image: "/curing-bladders.jpg",
    price: "Contact for pricing",
    inStock: true,
    featured: false,
  },
]

export function ProductGrid() {
  const [selectedCategory, setSelectedCategory] = useState("All")

  const filteredProducts =
    selectedCategory === "All" ? products : products.filter((product) => product.category === selectedCategory)

  return (
    <div>
      {/* Results Header */}
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold">{selectedCategory === "All" ? "All Products" : selectedCategory}</h2>
        <p className="text-muted-foreground">
          Showing {filteredProducts.length} of {products.length} products
        </p>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <CardContent className="p-0">
              {/* Product Image */}
              <div className="aspect-square overflow-hidden rounded-t-lg bg-muted relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {product.featured && <Badge className="absolute top-3 left-3 bg-primary">Featured</Badge>}
                {!product.inStock && (
                  <Badge variant="destructive" className="absolute top-3 right-3">
                    Out of Stock
                  </Badge>
                )}

                {/* Overlay Actions */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-2">
                  <Button size="sm" variant="secondary" asChild>
                    <Link href={`/products/${product.id}`}>
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Link>
                  </Button>
                </div>
              </div>

              {/* Product Info */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">{product.category}</Badge>
                  <span className="text-sm font-medium text-primary">{product.price}</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                <p className="text-muted-foreground text-sm mb-4 text-pretty">{product.description}</p>

                <div className="flex space-x-2">
                  <Button className="flex-1" asChild>
                    <Link href={`/products/${product.id}`}>
                      View Details
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button variant="outline">Quote</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Load More */}
      {filteredProducts.length >= 6 && (
        <div className="text-center mt-12">
          <Button variant="outline" size="lg">
            Load More Products
          </Button>
        </div>
      )}
    </div>
  )
}
