import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

const products = [
  {
    name: "Dunamis",
    image: "/dunamis-solid-tire.jpg",
    description: "High-performance solid tyres for heavy-duty applications",
  },
  {
    name: "Solitrek",
    image: "/solitrek-solid-tire.jpg",
    description: "Durable solid tyres for industrial equipment",
  },
  {
    name: "Solidwings",
    image: "/solidwings-solid-tire.jpg",
    description: "Premium solid tyres for material handling",
  },
  {
    name: "Rocksolid",
    image: "/rocksolid-solid-tire.jpg",
    description: "Ultra-durable tyres for extreme conditions",
  },
  {
    name: "Goliath",
    image: "/goliath-solid-tire.jpg",
    description: "Heavy-duty tyres for maximum load capacity",
  },
]

export function ProductShowcase() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-balance mb-4">Discover Our Range of Products</h2>
          <p className="text-xl text-muted-foreground text-balance max-w-2xl mx-auto">
            Explore our comprehensive range of solid tyres designed for various industrial applications
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {products.map((product, index) => (
            <Card key={product.name} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6">
                <div className="aspect-square mb-4 overflow-hidden rounded-lg bg-muted">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                <p className="text-muted-foreground text-sm mb-4 text-pretty">{product.description}</p>
                <Button
                  variant="ghost"
                  className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                >
                  Explore
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline">
            View All Products
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  )
}
