"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"

const categories = [
  { id: "solid-tyres", name: "Solid Tyres", count: 5 },
  { id: "tubes-flaps", name: "Tubes & Flaps", count: 2 },
  { id: "bladders", name: "Bladders", count: 1 },
  { id: "fitment-press", name: "Fitment Press", count: 3 },
]

const applications = [
  { id: "forklifts", name: "Forklifts", count: 8 },
  { id: "material-handling", name: "Material Handling", count: 6 },
  { id: "industrial", name: "Industrial Equipment", count: 5 },
  { id: "mining", name: "Mining", count: 3 },
  { id: "construction", name: "Construction", count: 4 },
]

const loadCapacities = [
  { id: "0-2000", name: "0 - 2000 kg", count: 3 },
  { id: "2000-4000", name: "2000 - 4000 kg", count: 4 },
  { id: "4000-6000", name: "4000 - 6000 kg", count: 2 },
  { id: "6000+", name: "6000+ kg", count: 2 },
]

export function ProductFilters() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedApplications, setSelectedApplications] = useState<string[]>([])
  const [selectedCapacities, setSelectedCapacities] = useState<string[]>([])

  const handleCategoryChange = (categoryId: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, categoryId])
    } else {
      setSelectedCategories(selectedCategories.filter((id) => id !== categoryId))
    }
  }

  const handleApplicationChange = (applicationId: string, checked: boolean) => {
    if (checked) {
      setSelectedApplications([...selectedApplications, applicationId])
    } else {
      setSelectedApplications(selectedApplications.filter((id) => id !== applicationId))
    }
  }

  const handleCapacityChange = (capacityId: string, checked: boolean) => {
    if (checked) {
      setSelectedCapacities([...selectedCapacities, capacityId])
    } else {
      setSelectedCapacities(selectedCapacities.filter((id) => id !== capacityId))
    }
  }

  const clearAllFilters = () => {
    setSelectedCategories([])
    setSelectedApplications([])
    setSelectedCapacities([])
  }

  const totalActiveFilters = selectedCategories.length + selectedApplications.length + selectedCapacities.length

  return (
    <div className="space-y-6">
      {/* Active Filters */}
      {totalActiveFilters > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">Active Filters</CardTitle>
              <Button variant="ghost" size="sm" onClick={clearAllFilters}>
                Clear All
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex flex-wrap gap-2">
              {selectedCategories.map((categoryId) => {
                const category = categories.find((c) => c.id === categoryId)
                return (
                  <Badge key={categoryId} variant="secondary" className="text-xs">
                    {category?.name}
                    <X
                      className="ml-1 h-3 w-3 cursor-pointer"
                      onClick={() => handleCategoryChange(categoryId, false)}
                    />
                  </Badge>
                )
              })}
              {selectedApplications.map((appId) => {
                const app = applications.find((a) => a.id === appId)
                return (
                  <Badge key={appId} variant="secondary" className="text-xs">
                    {app?.name}
                    <X className="ml-1 h-3 w-3 cursor-pointer" onClick={() => handleApplicationChange(appId, false)} />
                  </Badge>
                )
              })}
              {selectedCapacities.map((capId) => {
                const cap = loadCapacities.find((c) => c.id === capId)
                return (
                  <Badge key={capId} variant="secondary" className="text-xs">
                    {cap?.name}
                    <X className="ml-1 h-3 w-3 cursor-pointer" onClick={() => handleCapacityChange(capId, false)} />
                  </Badge>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Categories Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {categories.map((category) => (
              <div key={category.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={category.id}
                    checked={selectedCategories.includes(category.id)}
                    onCheckedChange={(checked) => handleCategoryChange(category.id, checked as boolean)}
                  />
                  <label htmlFor={category.id} className="text-sm font-medium cursor-pointer">
                    {category.name}
                  </label>
                </div>
                <span className="text-xs text-muted-foreground">({category.count})</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Applications Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {applications.map((application) => (
              <div key={application.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={application.id}
                    checked={selectedApplications.includes(application.id)}
                    onCheckedChange={(checked) => handleApplicationChange(application.id, checked as boolean)}
                  />
                  <label htmlFor={application.id} className="text-sm font-medium cursor-pointer">
                    {application.name}
                  </label>
                </div>
                <span className="text-xs text-muted-foreground">({application.count})</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Load Capacity Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Load Capacity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {loadCapacities.map((capacity) => (
              <div key={capacity.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={capacity.id}
                    checked={selectedCapacities.includes(capacity.id)}
                    onCheckedChange={(checked) => handleCapacityChange(capacity.id, checked as boolean)}
                  />
                  <label htmlFor={capacity.id} className="text-sm font-medium cursor-pointer">
                    {capacity.name}
                  </label>
                </div>
                <span className="text-xs text-muted-foreground">({capacity.count})</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
