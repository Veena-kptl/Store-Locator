import { Button } from "@/components/ui/button"
import { ArrowRight, Play } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-[80vh] flex items-center justify-center bg-gradient-to-br from-background to-muted">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[url('/industrial-tire-manufacturing-facility.jpg')] bg-cover bg-center opacity-10" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <h1 className="text-4xl md:text-6xl font-bold text-balance mb-6">
            Leading Manufacturers of <span className="text-primary">Solid Cushion Tyres</span>
          </h1>

          {/* Subheading */}
          <p className="text-xl md:text-2xl text-muted-foreground text-balance mb-8 max-w-3xl mx-auto">
            Rubber King Tyre Private Limited specializes in manufacturing premium quality solid tyres, tubes, flaps, and
            bladders with 4 state-of-art manufacturing plants in Gujarat.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button size="lg" className="text-lg px-8 py-6">
              Explore Our Products
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
              <Play className="mr-2 h-5 w-5" />
              Watch Video
            </Button>
          </div>

          {/* Key Features */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-3 bg-primary/10 rounded-full flex items-center justify-center">
                <img src="/delivery-truck-icon.png" alt="Free Delivery" className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-sm">PAN India Free Delivery</h3>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-3 bg-primary/10 rounded-full flex items-center justify-center">
                <img src="/warranty-icon.png" alt="Warranty" className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-sm">Quality Warranty</h3>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-3 bg-primary/10 rounded-full flex items-center justify-center">
                <img src="/fast-process-icon.jpg" alt="Fast Process" className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-sm">Faster Claim Process</h3>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-3 bg-primary/10 rounded-full flex items-center justify-center">
                <img src="/maintenance-icon.png" alt="AMC" className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-sm">Free AMC*</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
