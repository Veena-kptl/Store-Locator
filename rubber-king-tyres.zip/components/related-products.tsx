import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

const allProducts = [
  {
    id: "dunamis",
    name: "Dunamis",
    category: "Solid Tyres",
    description: "High-performance solid tyres for heavy-duty applications",
    image: "/dunamis-solid-tire.jpg",
    price: "Contact for pricing",
  },
  {
    id: "solitrek",
    name: "Solitrek",
    category: "Solid Tyres",
    description: "Durable solid tyres for industrial equipment",
    image: "/solitrek-solid-tire.jpg",
    price: "Contact for pricing",
  },
  {
    id: "solidwings",
    name: "Solidwings",
    category: "Solid Tyres",
    description: "Premium solid tyres for material handling",
    image: "/solidwings-solid-tire.jpg",
    price: "Contact for pricing",
  },
  {
    id: "rocksolid",
    name: "Rocksolid",
    category: "Solid Tyres",
    description: "Ultra-durable tyres for extreme conditions",
    image: "/rocksolid-solid-tire.jpg",
    price: "Contact for pricing",
  },
  {
    id: "goliath",
    name: "Goliath",
    category: "Solid Tyres",
    description: "Heavy-duty tyres for maximum load capacity",
    image: "/goliath-solid-tire.jpg",
    price: "Contact for pricing",
  },
]

interface RelatedProductsProps {
  currentProductId: string
}

export function RelatedProducts({ currentProductId }: RelatedProductsProps) {
  const relatedProducts = allProducts.filter((product) => product.id !== currentProductId).slice(0, 4)

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-balance mb-4">Related Products</h2>
          <p className="text-xl text-muted-foreground text-balance">Explore other products in our range</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {relatedProducts.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="aspect-square overflow-hidden rounded-t-lg bg-muted">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-2">{product.name}</h3>
                  <p className="text-muted-foreground text-sm mb-3 text-pretty">{product.description}</p>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-primary">{product.price}</span>
                  </div>
                  <Button variant="outline" size="sm" className="w-full bg-transparent" asChild>
                    <Link href={`/products/${product.id}`}>
                      View Details
                      <ArrowRight className="ml-2 h-3 w-3" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" asChild>
            <Link href="/products">
              View All Products
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
