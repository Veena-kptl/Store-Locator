import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductDetails } from "@/components/product-details"
import { RelatedProducts } from "@/components/related-products"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { notFound } from "next/navigation"

// Mock product data - in a real app, this would come from a database
const products = {
  dunamis: {
    id: "dunamis",
    name: "Dunamis",
    category: "Solid Tyres",
    description:
      "High-performance solid tyres designed for heavy-duty applications with superior durability and load-bearing capacity.",
    fullDescription:
      "The Dunamis series represents our flagship solid tyre line, engineered for the most demanding industrial applications. These tyres feature advanced compound technology that provides exceptional wear resistance, superior heat dissipation, and optimal load distribution. Perfect for forklifts, material handling equipment, and heavy industrial machinery.",
    features: [
      "Superior load-bearing capacity",
      "Enhanced heat dissipation",
      "Advanced compound technology",
      "Excellent wear resistance",
      "Optimal traction and stability",
    ],
    specifications: {
      "Load Capacity": "Up to 5000 kg",
      "Operating Temperature": "-20°C to +80°C",
      Compound: "Advanced rubber compound",
      "Tread Pattern": "Non-marking available",
      "Sizes Available": 'Multiple sizes from 6" to 21"',
    },
    applications: ["Forklifts", "Material Handling", "Industrial Equipment", "Warehouse Operations"],
    images: ["/dunamis-solid-tire.jpg", "/dunamis-tire-2.jpg", "/dunamis-tire-3.jpg"],
    price: "Contact for pricing",
    inStock: true,
  },
  solitrek: {
    id: "solitrek",
    name: "Solitrek",
    category: "Solid Tyres",
    description: "Durable solid tyres engineered for industrial equipment with excellent performance and longevity.",
    fullDescription:
      "Solitrek tyres are designed for versatile industrial applications, offering a perfect balance of durability, performance, and cost-effectiveness. These tyres feature innovative tread designs and compound formulations that ensure reliable performance across various operating conditions.",
    features: [
      "Versatile industrial applications",
      "Cost-effective solution",
      "Reliable performance",
      "Innovative tread design",
      "Long service life",
    ],
    specifications: {
      "Load Capacity": "Up to 4000 kg",
      "Operating Temperature": "-15°C to +70°C",
      Compound: "Standard rubber compound",
      "Tread Pattern": "Multi-directional",
      "Sizes Available": '6" to 18"',
    },
    applications: ["Industrial Equipment", "Port Operations", "Construction", "Mining"],
    images: ["/solitrek-solid-tire.jpg", "/solitrek-tire-2.jpg"],
    price: "Contact for pricing",
    inStock: true,
  },
  solidwings: {
    id: "solidwings",
    name: "Solidwings",
    category: "Solid Tyres",
    description: "Premium solid tyres for material handling equipment with superior grip and stability.",
    fullDescription:
      "Solidwings tyres are specifically engineered for material handling applications, providing exceptional grip, stability, and maneuverability. The unique wing-pattern tread design ensures optimal performance in both indoor and outdoor environments.",
    features: [
      "Superior grip and stability",
      "Wing-pattern tread design",
      "Indoor/outdoor versatility",
      "Enhanced maneuverability",
      "Reduced vibration",
    ],
    specifications: {
      "Load Capacity": "Up to 3500 kg",
      "Operating Temperature": "-10°C to +60°C",
      Compound: "Specialized grip compound",
      "Tread Pattern": "Wing-pattern",
      "Sizes Available": '8" to 16"',
    },
    applications: ["Material Handling", "Reach Trucks", "Order Pickers", "Stackers"],
    images: ["/solidwings-solid-tire.jpg", "/solidwings-tire-2.jpg"],
    price: "Contact for pricing",
    inStock: true,
  },
  rocksolid: {
    id: "rocksolid",
    name: "Rocksolid",
    category: "Solid Tyres",
    description: "Ultra-durable tyres designed for extreme conditions and heavy-duty operations.",
    fullDescription:
      "Rocksolid tyres are built to withstand the harshest operating conditions. With reinforced construction and specialized compounds, these tyres deliver unmatched durability and performance in extreme environments.",
    features: [
      "Extreme condition resistance",
      "Reinforced construction",
      "Specialized compounds",
      "Maximum durability",
      "Heavy-duty performance",
    ],
    specifications: {
      "Load Capacity": "Up to 6000 kg",
      "Operating Temperature": "-30°C to +90°C",
      Compound: "Extreme duty compound",
      "Tread Pattern": "Deep lug",
      "Sizes Available": '10" to 24"',
    },
    applications: ["Mining", "Steel Mills", "Foundries", "Heavy Construction"],
    images: ["/rocksolid-solid-tire.jpg", "/rocksolid-tire-2.jpg"],
    price: "Contact for pricing",
    inStock: true,
  },
  goliath: {
    id: "goliath",
    name: "Goliath",
    category: "Solid Tyres",
    description: "Heavy-duty tyres engineered for maximum load capacity and extreme durability.",
    fullDescription:
      "Goliath represents the pinnacle of heavy-duty tyre engineering. Designed for the most demanding applications, these tyres offer maximum load capacity, exceptional durability, and reliable performance under extreme conditions.",
    features: [
      "Maximum load capacity",
      "Exceptional durability",
      "Extreme condition performance",
      "Reinforced sidewalls",
      "Long service intervals",
    ],
    specifications: {
      "Load Capacity": "Up to 8000 kg",
      "Operating Temperature": "-25°C to +85°C",
      Compound: "Ultra-heavy duty compound",
      "Tread Pattern": "Aggressive lug",
      "Sizes Available": '12" to 28"',
    },
    applications: ["Port Handling", "Heavy Mining", "Steel Industry", "Large Forklifts"],
    images: ["/goliath-solid-tire.jpg", "/goliath-tire-2.jpg"],
    price: "Contact for pricing",
    inStock: true,
  },
}

interface ProductPageProps {
  params: {
    slug: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = products[params.slug as keyof typeof products]

  if (!product) {
    notFound()
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Breadcrumb */}
        <div className="container mx-auto px-4 py-6">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink href="/">Home</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink href="/products">Products</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{product.name}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>

        <ProductDetails product={product} />
        <RelatedProducts currentProductId={product.id} />
      </main>
      <Footer />
    </div>
  )
}

export async function generateStaticParams() {
  return Object.keys(products).map((slug) => ({
    slug,
  }))
}
