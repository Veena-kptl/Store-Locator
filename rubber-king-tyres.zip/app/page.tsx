import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ProductShowcase } from "@/components/product-showcase"
import { ServicesSection } from "@/components/services-section"
import { CompanyInfo } from "@/components/company-info"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <ProductShowcase />
        <ServicesSection />
        <CompanyInfo />
      </main>
      <Footer />
    </div>
  )
}
