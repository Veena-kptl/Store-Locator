const jQuery = window.jQuery
rubberking_ajax = window.rubberking_ajax

jQuery(document).ready(($) => {
  let currentSection = 1
  const totalSections = 8

  // Initialize progress indicator
  //initProgressIndicator()

  // Handle section navigation
 /* $(".btn-next").on("click", () => {
    if (validateCurrentSection()) {
      nextSection()
    }
  })

  $(".btn-prev").on("click", () => {
    prevSection()
  })*/

  // Handle conditional fields
  $("#tyre_size").on("change", function () {
    if ($(this).val() === "other") {
      $("#tyre_size_other_group").show()
      $("#tyre_size_other").prop("required", true)
    } else {
      $("#tyre_size_other_group").hide()
      $("#tyre_size_other").prop("required", false)
    }
  })

  $("#tyre_brand").on("change", function () {
    if ($(this).val() === "other") {
      $("#tyre_brand_other_group").show()
      $("#tyre_brand_other").prop("required", true)
    } else {
      $("#tyre_brand_other_group").hide()
      $("#tyre_brand_other").prop("required", false)
    }
  })

  // Handle payment mode selection
  $('input[name="payment_mode"]').on("change", function () {
    const paymentMode = $(this).val()

    if (paymentMode === "bank_transfer") {
      // Make bank fields required
      $("#account_holder_name, #bank_account_number, #bank_name, #ifsc_code").prop("required", true)
      $("#upi_id, #upi_name").prop("required", false)
    } else if (paymentMode === "upi") {
      // Make UPI fields required
      $("#upi_id, #upi_name").prop("required", true)
      $("#account_holder_name, #bank_account_number, #bank_name, #ifsc_code").prop("required", false)
    }
  })

  // Handle form submission
  $("#rubberking-form").on("submit", function (e) {
    e.preventDefault()

    if (!validateCurrentSection()) {
      return
    }

    const formData = new FormData(this)
    formData.append("action", "submit_rubberking_registration")

    // Show loading state
    $(this).addClass("loading")
    $(".btn-submit").text("Submitting...")

    $.ajax({
      url: rubberking_ajax.ajax_url,
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: (response) => {
        if (response.success) {
          showSuccessMessage(response.data.message)
        } else {
          showError(response.data || "Submission failed. Please try again.")
        }
      },
      error: () => {
        showError("Network error. Please check your connection and try again.")
      },
      complete: () => {
        $("#rubberking-form").removeClass("loading")
        $(".btn-submit").text("Submit Registration")
      },
    })
  })

  // Phone number validation
  $("#phone_number").on("input", function () {
    let value = $(this).val().replace(/\D/g, "")
    if (value.length > 10) {
      value = value.substring(0, 10)
    }
    $(this).val(value)
  })

  // Pincode validation
  $("#pincode").on("input", function () {
    let value = $(this).val().replace(/\D/g, "")
    if (value.length > 6) {
      value = value.substring(0, 6)
    }
    $(this).val(value)
  })

  // IFSC code validation
  $("#ifsc_code").on("input", function () {
    const value = $(this).val().toUpperCase()
    $(this).val(value)
  })

 /* function initProgressIndicator() {
    const progressHtml = `
            <div class="progress-indicator">
                ${Array.from(
                  { length: totalSections },
                  (_, i) => `
                    <div class="progress-step ${i === 0 ? "active" : ""}" data-step="${i + 1}">
                        <div class="progress-step-number">${i + 1}</div>
                        <div class="progress-step-label">Section ${i + 1}</div>
                    </div>
                `,
                ).join("")}
            </div>
        `

    $(".rubberking-header").after(progressHtml)
  }

  function nextSection() {
    if (currentSection < totalSections) {
      $(`[data-section="${currentSection}"]`).hide()
      currentSection++
      $(`[data-section="${currentSection}"]`).show()
      updateProgressIndicator()
      scrollToTop()
    }
  }

  function prevSection() {
    if (currentSection > 1) {
      $(`[data-section="${currentSection}"]`).hide()
      currentSection--
      $(`[data-section="${currentSection}"]`).show()
      updateProgressIndicator()
      scrollToTop()
    }
  }

  function updateProgressIndicator() {
    $(".progress-step").removeClass("active completed")

    for (let i = 1; i < currentSection; i++) {
      $(`.progress-step[data-step="${i}"]`).addClass("completed")
    }

    $(`.progress-step[data-step="${currentSection}"]`).addClass("active")
  }*/

  function validateCurrentSection() {
    const currentSectionElement = $(`[data-section="${currentSection}"]`)
    let isValid = true

    // Clear previous errors
    currentSectionElement.find(".form-group").removeClass("error")
    currentSectionElement.find(".error-message").remove()

    // Validate required fields
    currentSectionElement.find("input[required], select[required], textarea[required]").each(function () {
      const $field = $(this)
      const $group = $field.closest(".form-group")

      if (!$field.val().trim()) {
        $group.addClass("error")
        $group.append('<div class="error-message">This field is required.</div>')
        isValid = false
      }
    })

    // Custom validations
    if (currentSection === 1) {
      // Phone number validation
      const phone = $("#phone_number").val()
      if (phone && !/^\d{10}$/.test(phone)) {
        $("#phone_number").closest(".form-group").addClass("error")
        $("#phone_number")
          .closest(".form-group")
          .append('<div class="error-message">Please enter a valid 10-digit phone number.</div>')
        isValid = false
      }

      // Pincode validation
      const pincode = $("#pincode").val()
      if (pincode && !/^\d{6}$/.test(pincode)) {
        $("#pincode").closest(".form-group").addClass("error")
        $("#pincode")
          .closest(".form-group")
          .append('<div class="error-message">Please enter a valid 6-digit pincode.</div>')
        isValid = false
      }

      // Email validation (if provided)
      const email = $("#email").val()
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        $("#email").closest(".form-group").addClass("error")
        $("#email")
          .closest(".form-group")
          .append('<div class="error-message">Please enter a valid email address.</div>')
        isValid = false
      }
    }

    if (currentSection === 4) {
      // Payment mode validation
      if (!$('input[name="payment_mode"]:checked').length) {
        $(".radio-group").closest(".form-group").addClass("error")
        $(".radio-group")
          .closest(".form-group")
          .append('<div class="error-message">Please select a payment mode.</div>')
        isValid = false
      }
    }

    if (currentSection === 5) {
      // Bank details validation (only if bank transfer is selected)
      if ($('input[name="payment_mode"]:checked').val() === "bank_transfer") {
        const ifsc = $("#ifsc_code").val()
        if (ifsc && !/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc)) {
          $("#ifsc_code").closest(".form-group").addClass("error")
          $("#ifsc_code")
            .closest(".form-group")
            .append('<div class="error-message">Please enter a valid IFSC code.</div>')
          isValid = false
        }
      }
    }

    if (currentSection === 6) {
      // UPI validation (only if UPI is selected)
      if ($('input[name="payment_mode"]:checked').val() === "upi") {
        const upiId = $("#upi_id").val()
        if (upiId && !/^[\w.-]+@[\w.-]+$/.test(upiId)) {
          $("#upi_id").closest(".form-group").addClass("error")
          $("#upi_id").closest(".form-group").append('<div class="error-message">Please enter a valid UPI ID.</div>')
          isValid = false
        }
      }
    }

    if (currentSection === 8) {
      // Declaration validation
      if (!$('input[name="declaration_accepted"]:checked').length) {
        $('input[name="declaration_accepted"]').closest(".form-group").addClass("error")
        $('input[name="declaration_accepted"]')
          .closest(".form-group")
          .append('<div class="error-message">You must accept the declaration to proceed.</div>')
        isValid = false
      }
    }

    return isValid
  }

  function showSuccessMessage(message) {
    const successHtml = `
            <div class="rubberking-success">
                <h3>Registration Successful!</h3>
                <p>${message}</p>
                <img src="${rubberking_ajax.plugin_url}assets/images/logo.png" alt="RubberKing Tyres" class="company-logo" style="display: none;">
            </div>
        `

    $("#rubberking-form").hide()
    $(".progress-indicator").hide()
    $("#rubberking-success-message").html(successHtml).show()
    scrollToTop()
  }

  function showError(message) {
    alert("Error: " + message)
  }

  function scrollToTop() {
    $("html, body").animate(
      {
        scrollTop: $(".rubberking-form-container").offset().top - 20,
      },
      300,
    )
  }

  // Handle section visibility based on payment mode
  function updateSectionVisibility() {
    var paymentMode = $('input[name="payment_mode"]:checked').val()
	console.log(paymentMode);
    if (paymentMode != "bank_transfer") {
      $(".upi-details").show();
	  $(".bank-details").hide();
    } else if (paymentMode != "upi") {
      $(".bank-details").show();
	  $(".upi-details").hide();
    }
  }

  // Update section visibility when payment mode changes
  $('input[name="payment_mode"]').on("change", updateSectionVisibility)
  $(".bank-details").hide();
	$(".upi-details").hide();
})
