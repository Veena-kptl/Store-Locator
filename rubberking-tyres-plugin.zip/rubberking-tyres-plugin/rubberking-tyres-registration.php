<?php
/**
 * Plugin Name: RubberKing Tyres Registration
 * Plugin URI: https://rubberkingtyres.com
 * Description: A comprehensive registration form for RubberKing Tyres promotional items and cashback processing.
 * Version: 1.0.0
 * Author: RubberKing Tyres
 * License: GPL v2 or later
 * Text Domain: rubberking-tyres
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('RUBBERKING_PLUGIN_URL', plugin_dir_url(__FILE__));
define('RUBBERKING_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('RUBBERKING_VERSION', '1.0.0');

class RubberKingTyresRegistration {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        // Load text domain for translations
        load_plugin_textdomain('rubberking-tyres', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Initialize admin
        if (is_admin()) {
            require_once RUBBERKING_PLUGIN_PATH . 'includes/admin.php';
            new RubberKing_Admin();
        }
        
        // Initialize frontend
        require_once RUBBERKING_PLUGIN_PATH . 'includes/frontend.php';
        new RubberKing_Frontend();
        
        // Initialize database
        require_once RUBBERKING_PLUGIN_PATH . 'includes/database.php';
        new RubberKing_Database();
        
        // Initialize email handler
        require_once RUBBERKING_PLUGIN_PATH . 'includes/email-handler.php';
        new RubberKing_Email_Handler();
        
        // Initialize file handler
        require_once RUBBERKING_PLUGIN_PATH . 'includes/file-handler.php';
        new RubberKing_File_Handler();
    }
    
    public function activate() {
        // Create database tables
        require_once RUBBERKING_PLUGIN_PATH . 'includes/database.php';
        RubberKing_Database::create_tables();
        
        // Set default options
        $this->set_default_options();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Schedule cleanup task
        if (!wp_next_scheduled('rubberking_cleanup_files')) {
            wp_schedule_event(time(), 'daily', 'rubberking_cleanup_files');
        }
    }
    
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Clear scheduled events
        wp_clear_scheduled_hook('rubberking_cleanup_files');
    }
    
    private function set_default_options() {
        // Default success message
        $default_success_message = "Thank you for choosing RubberKing Tyres! Your registration has been submitted successfully. We will process your request and contact you soon.";
        add_option('rubberking_success_message', $default_success_message);
        
        // Default email template
        $default_email_template = "Dear {customer_name},\n\nThank you for registering with RubberKing Tyres!\n\nYour registration details:\n- Phone: {phone_number}\n- Address: {address}\n- Tyre Size: {tyre_size}\n- Tyre Brand: {tyre_brand}\n- Number of Tyres: {number_of_tyres}\n\nWe will process your request soon.\n\nBest regards,\nRubberKing Tyres Team";
        add_option('rubberking_email_template', $default_email_template);
        
        // Default states list
        $default_states = array(
            'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
            'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
            'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
            'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
            'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
            'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Andaman and Nicobar Islands',
            'Chandigarh', 'Dadra & Nagar Haveli and Daman & Diu', 'Delhi (NCT)',
            'Jammu & Kashmir', 'Ladakh', 'Lakshadweep', 'Puducherry'
        );
        add_option('rubberking_states', $default_states);
        
        // Default tyre sizes
        $default_tyre_sizes = array(
            '9.00-20', '10.00-20', '11.00-20', '12.00-20', '12.00-24',
            '9.00-16', '14.00-25', '14.00-24', '13.00-24', '6.00-9',
            '6.50-10', '7.00-12', '8.15-15', '8.25-15', '10-16.5',
            '12-16.5', '6.00-16', '7.50-16', '6.50-20', '12.4-28',
            '13.6-28', '14.9-28', '16.9-28', '18X8.5-8', '205/50-10',
            '20.5-25', '23.5-25', '18.00-25', '23.1-26', '11.00-20'
        );
        add_option('rubberking_tyre_sizes', $default_tyre_sizes);
        
        // Default tyre brands
        $default_tyre_brands = array(
            'JWALA', 'Dinesha', 'Cleo', 'Petra', 'Agrim', 'Orion',
            'Vesper', 'Scorpion King', 'Air lift', 'SIMBA', 'Agrim/AVIRAL',
            'Sultan', 'Wazir', 'Dunestar', 'EMPEROR', 'Smooth 4S',
            'Smooth 5S', 'Mining', 'Lug', 'Cobraking', 'Sarvatra',
            'BLIMP', 'Green tyre', 'Farm'
        );
        add_option('rubberking_tyre_brands', $default_tyre_brands);
    }
}

// Initialize the plugin
new RubberKingTyresRegistration();
