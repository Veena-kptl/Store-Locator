<?php
if (!defined('ABSPATH')) {
    exit;
}

class RubberKing_Email_Handler {
    
    public function __construct() {
        // Constructor
    }
    
    public function send_registration_email($data, $registration_id) {
        $customer_email = $data['email'];
        
        if (empty($customer_email)) {
            return false;
        }
        
        // Get email template
        $template = get_option('rubberking_email_template', '');
		$email_id = get_option('rubberking_email_id', '');
        
        if (empty($template)) {
            return false;
        }
        
        // Replace placeholders
        $message = $this->replace_placeholders($template, $data, $registration_id);
        
        // Email headers
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: RubberKing Tyres <'.$email_id.'>'
        );
        
        $subject = 'Registration Confirmation - RubberKing Tyres';
        
        // Send email
        return wp_mail($customer_email, $subject, nl2br($message), $headers);
    }
    
    private function replace_placeholders($template, $data, $registration_id) {
        $placeholders = array(
            '{customer_name}' => $data['customer_name'],
            '{phone_number}' => $data['phone_number'],
            '{email}' => $data['email'],
            '{address}' => $data['address'],
            '{city}' => $data['city'],
            '{pincode}' => $data['pincode'],
            '{state}' => $data['state'],
            '{tyre_size}' => $data['tyre_size'] === 'other' ? $data['tyre_size_other'] : $data['tyre_size'],
            '{tyre_brand}' => $data['tyre_brand'] === 'other' ? $data['tyre_brand_other'] : $data['tyre_brand'],
            '{number_of_tyres}' => $data['number_of_tyres'],
            '{payment_mode}' => ucfirst(str_replace('_', ' ', $data['payment_mode'])),
            '{registration_id}' => $registration_id,
            '{date}' => date('F j, Y')
        );
        
        return str_replace(array_keys($placeholders), array_values($placeholders), $template);
    }
}
