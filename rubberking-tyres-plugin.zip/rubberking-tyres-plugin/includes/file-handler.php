<?php
if (!defined('ABSPATH')) {
    exit;
}

class RubberKing_File_Handler {
    
    private $upload_dir;
    private $allowed_types;
    private $max_file_size;
    
    public function __construct() {
        $upload_dir = wp_upload_dir();
        $this->upload_dir = $upload_dir['basedir'] . '/rubberking-registrations';
        $this->allowed_types = array('jpg', 'jpeg', 'png', 'pdf');
        $this->max_file_size = 5 * 1024 * 1024; // 5MB
        
        $this->ensure_upload_directory();
        add_action('wp_ajax_download_registration_file', array($this, 'handle_file_download'));
    }
    
    private function ensure_upload_directory() {
        if (!file_exists($this->upload_dir)) {
            wp_mkdir_p($this->upload_dir);
            
            // Create .htaccess file for security
            $htaccess_content = "Options -Indexes\n";
            $htaccess_content .= "<Files *.php>\n";
            $htaccess_content .= "Deny from all\n";
            $htaccess_content .= "</Files>\n";
            $htaccess_content .= "<Files *.exe>\n";
            $htaccess_content .= "Deny from all\n";
            $htaccess_content .= "</Files>\n";
            
            file_put_contents($this->upload_dir . '/.htaccess', $htaccess_content);
            
            // Create index.php to prevent directory listing
            file_put_contents($this->upload_dir . '/index.php', '<?php // Silence is golden');
        }
    }
    
    public function handle_file_upload($file_key, $registration_id = null) {
        if (!isset($_FILES[$file_key]) || $_FILES[$file_key]['error'] !== UPLOAD_ERR_OK) {
            return false;
        }
        
        $file = $_FILES[$file_key];
        
        // Validate file size
        if ($file['size'] > $this->max_file_size) {
            return array('error' => 'File size exceeds 5MB limit');
        }
        
        // Validate file type
        $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($file_extension, $this->allowed_types)) {
            return array('error' => 'Invalid file type. Only JPG, PNG, and PDF files are allowed');
        }
        
        // Generate unique filename
        $filename = $this->generate_unique_filename($file['name'], $registration_id);
        $file_path = $this->upload_dir . '/' . $filename;
        
        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            // Additional security: validate file content
            if ($this->validate_file_content($file_path, $file_extension)) {
                return $filename;
            } else {
                unlink($file_path); // Delete invalid file
                return array('error' => 'Invalid file content');
            }
        }
        
        return false;
    }
    
    private function generate_unique_filename($original_name, $registration_id = null) {
        $file_extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
        $base_name = sanitize_file_name(pathinfo($original_name, PATHINFO_FILENAME));
        
        $prefix = $registration_id ? "reg_{$registration_id}_" : '';
        $timestamp = time();
        $random = wp_generate_password(8, false);
        
        return $prefix . $base_name . '_' . $timestamp . '_' . $random . '.' . $file_extension;
    }
    
    private function validate_file_content($file_path, $expected_extension) {
        // Get actual file type using finfo
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type = finfo_file($finfo, $file_path);
            finfo_close($finfo);
            
            $allowed_mimes = array(
                'jpg' => array('image/jpeg', 'image/jpg'),
                'jpeg' => array('image/jpeg', 'image/jpg'),
                'png' => array('image/png'),
                'pdf' => array('application/pdf')
            );
            
            if (isset($allowed_mimes[$expected_extension])) {
                return in_array($mime_type, $allowed_mimes[$expected_extension]);
            }
        }
        
        // Fallback validation using getimagesize for images
        if (in_array($expected_extension, array('jpg', 'jpeg', 'png'))) {
            $image_info = getimagesize($file_path);
            return $image_info !== false;
        }
        
        // For PDF, check file signature
        if ($expected_extension === 'pdf') {
            $file_handle = fopen($file_path, 'rb');
            $file_header = fread($file_handle, 4);
            fclose($file_handle);
            
            return $file_header === '%PDF';
        }
        
        return true; // Default to true if we can't validate
    }
    
    public function get_file_url($filename) {
        if (empty($filename) || !file_exists($this->upload_dir . '/' . $filename)) {
            return false;
        }
        
        // Return admin download URL for security
        return admin_url('admin-ajax.php?action=download_registration_file&file=' . urlencode($filename) . '&nonce=' . wp_create_nonce('download_file_' . $filename));
    }
    
    public function handle_file_download() {
        $filename = sanitize_file_name($_GET['file']);
        $nonce = $_GET['nonce'];
        
        // Verify nonce
        if (!wp_verify_nonce($nonce, 'download_file_' . $filename)) {
            wp_die('Security check failed');
        }
        
        // Check user permissions
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        $file_path = $this->upload_dir . '/' . $filename;
        
        if (!file_exists($file_path)) {
            wp_die('File not found');
        }
        
        // Get file info
        $file_extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $mime_types = array(
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'pdf' => 'application/pdf'
        );
        
        $mime_type = isset($mime_types[$file_extension]) ? $mime_types[$file_extension] : 'application/octet-stream';
        
        // Set headers
        header('Content-Type: ' . $mime_type);
        header('Content-Disposition: inline; filename="' . basename($filename) . '"');
        header('Content-Length: ' . filesize($file_path));
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');
        
        // Output file
        readfile($file_path);
        exit;
    }
    
    public function delete_file($filename) {
        if (empty($filename)) {
            return false;
        }
        
        $file_path = $this->upload_dir . '/' . $filename;
        
        if (file_exists($file_path)) {
            return unlink($file_path);
        }
        
        return true; // File doesn't exist, consider it deleted
    }
    
    public function get_file_info($filename) {
        if (empty($filename)) {
            return false;
        }
        
        $file_path = $this->upload_dir . '/' . $filename;
        
        if (!file_exists($file_path)) {
            return false;
        }
        
        return array(
            'filename' => $filename,
            'size' => filesize($file_path),
            'size_formatted' => size_format(filesize($file_path)),
            'type' => strtoupper(pathinfo($filename, PATHINFO_EXTENSION)),
            'upload_date' => date('Y-m-d H:i:s', filemtime($file_path)),
            'download_url' => $this->get_file_url($filename)
        );
    }
    
    public static function cleanup_orphaned_files() {
        global $wpdb;
        
        $upload_dir = wp_upload_dir();
        $rubberking_dir = $upload_dir['basedir'] . '/rubberking-registrations';
        
        if (!is_dir($rubberking_dir)) {
            return;
        }
        
        // Get all files in directory
        $files = glob($rubberking_dir . '/*');
        $files = array_filter($files, 'is_file');
        
        // Get all files referenced in database
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        $db_files = $wpdb->get_col("
            SELECT DISTINCT filename FROM (
                SELECT id_card_file as filename FROM $table_name WHERE id_card_file != ''
                UNION
                SELECT invoice_file as filename FROM $table_name WHERE invoice_file != ''
            ) as all_files
        ");
        
        // Delete orphaned files (older than 24 hours)
        foreach ($files as $file_path) {
            $filename = basename($file_path);
            
            // Skip system files
            if (in_array($filename, array('.htaccess', 'index.php'))) {
                continue;
            }
            
            // Skip if file is referenced in database
            if (in_array($filename, $db_files)) {
                continue;
            }
            
            // Delete if older than 24 hours
            if (filemtime($file_path) < (time() - 24 * 60 * 60)) {
                unlink($file_path);
            }
        }
    }
}
