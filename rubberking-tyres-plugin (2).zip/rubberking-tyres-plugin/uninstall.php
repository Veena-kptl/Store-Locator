<?php
/**
 * Uninstall script for RubberKing Tyres Registration Plugin
 * 
 * This file is executed when the plugin is deleted from WordPress admin.
 * It removes all plugin data including database tables, options, and uploaded files.
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Remove database table
global $wpdb;
$table_name = $wpdb->prefix . 'rubberking_registrations';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

// Remove plugin options
delete_option('rubberking_success_message');
delete_option('rubberking_email_template');
delete_option('rubberking_states');
delete_option('rubberking_tyre_sizes');
delete_option('rubberking_tyre_brands');

// Remove uploaded files directory
$upload_dir = wp_upload_dir();
$rubberking_dir = $upload_dir['basedir'] . '/rubberking-registrations';

if (is_dir($rubberking_dir)) {
    // Remove all files in the directory
    $files = glob($rubberking_dir . '/*');
    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file);
        }
    }
    
    // Remove the directory
    rmdir($rubberking_dir);
}

// Clear any scheduled events
wp_clear_scheduled_hook('rubberking_cleanup_files');

// Remove any cached data
wp_cache_flush();
