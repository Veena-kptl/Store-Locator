const jQuery = window.jQuery
rubberking_admin_ajax = window.rubberking_admin_ajax

jQuery(document).ready(($) => {
  // Handle status updates
  $(".status-select").on("change", function () {
    const registrationId = $(this).data("id")
    const status = $(this).val()

    $.ajax({
      url: rubberking_admin_ajax.ajax_url,
      type: "POST",
      data: {
        action: "update_registration_status",
        registration_id: registrationId,
        status: status,
        nonce: rubberking_admin_ajax.nonce,
      },
      success: (response) => {
        if (response.success) {
          showNotice("Status updated successfully", "success")
        } else {
          showNotice("Failed to update status", "error")
        }
      },
      error: () => {
        showNotice("Network error occurred", "error")
      },
    })
  })

  // Handle select all checkbox
  $("#select-all").on("change", function () {
    $('input[name="registration_ids[]"]').prop("checked", $(this).prop("checked"))
  })

  // Handle individual checkboxes
  $('input[name="registration_ids[]"]').on("change", () => {
    const totalCheckboxes = $('input[name="registration_ids[]"]').length
    const checkedCheckboxes = $('input[name="registration_ids[]"]:checked').length

    $("#select-all").prop("checked", totalCheckboxes === checkedCheckboxes)
  })

  // Handle dropdown management
  $(".add-item").on("click", function () {
    const container = $(this).siblings(".dropdown-items")
    const type = $(this).closest(".dropdown-manager").data("type")

    let inputName = ""
    let placeholder = ""

    switch (type) {
      case "states":
        inputName = "states[]"
        placeholder = "Enter state name"
        break
      case "tyre_sizes":
        inputName = "tyre_sizes[]"
        placeholder = "Enter tyre size"
        break
      case "tyre_brands":
        inputName = "tyre_brands[]"
        placeholder = "Enter tyre brand"
        break
    }

    const newItem = `
            <div class="dropdown-item">
                <input type="text" name="${inputName}" placeholder="${placeholder}">
                <button type="button" class="button remove-item">Remove</button>
            </div>
        `

    container.append(newItem)
  })

  // Handle item removal
  $(document).on("click", ".remove-item", function () {
    $(this).closest(".dropdown-item").remove()
  })

  // Modal functionality
  $(".rubberking-modal-close").on("click", () => {
    $(".rubberking-modal").hide()
  })

  $(window).on("click", (event) => {
    if ($(event.target).hasClass("rubberking-modal")) {
      $(".rubberking-modal").hide()
    }
  })
})

// Global functions
function viewRegistration(id) {
  // This would typically make an AJAX call to get registration details
  // For now, we'll show a placeholder
  const modalContent = `
        <h2>Registration Details - ID: ${id}</h2>
        <p>Loading registration details...</p>
    `

  jQuery("#registration-details").html(modalContent)
  jQuery("#registration-modal").show()

  // Make AJAX call to get full registration details
  jQuery.ajax({
    url: rubberking_admin_ajax.ajax_url,
    type: "POST",
    data: {
      action: "get_registration_details",
      registration_id: id,
      nonce: rubberking_admin_ajax.nonce,
    },
    success: (response) => {
      if (response.success) {
        jQuery("#registration-details").html(response.data.html);
		window.stop();
      }
    },
  })
}

function deleteRegistration(id) {
  if (!confirm("Are you sure you want to delete this registration? This action cannot be undone.")) {
    return
  }

  jQuery.ajax({
    url: rubberking_admin_ajax.ajax_url,
    type: "POST",
    data: {
      action: "delete_registration",
      registration_id: id,
      nonce: rubberking_admin_ajax.nonce,
    },
    success: (response) => {
      if (response.success) {
        //location.reload()
      } else {
        alert("Failed to delete registration")
      }
    },
    error: () => {
      alert("Network error occurred")
    },
  })
}

function exportRegistrations() {
  jQuery.ajax({
    url: rubberking_admin_ajax.ajax_url,
    type: "POST",
    data: {
      action: "export_registrations",
      nonce: rubberking_admin_ajax.nonce,
    },
    success: (response) => {
      if (response.success) {
        downloadCSV(response.data.csv_data)
      } else {
        alert("Failed to export registrations")
      }
    },
    error: () => {
      alert("Network error occurred")
    },
  })
}

function downloadCSV(csvData) {
  let csvContent = ""

  csvData.forEach((row) => {
    const csvRow = row
      .map((field) => {
        // Escape quotes and wrap in quotes if necessary
        if (field === null || field === undefined) {
          return ""
        }

        const stringField = String(field)
        if (stringField.includes(",") || stringField.includes('"') || stringField.includes("\n")) {
          return '"' + stringField.replace(/"/g, '""') + '"'
        }
        return stringField
      })
      .join(",")

    csvContent += csvRow + "\n"
  })

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")

  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", "rubberking-registrations-" + new Date().toISOString().split("T")[0] + ".csv")
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }
}

function applyBulkAction() {
  const action = jQuery("#bulk-action").val()
  const selectedIds = jQuery('input[name="registration_ids[]"]:checked')
    .map(function () {
      return this.value
    })
    .get()

  if (!action) {
    alert("Please select a bulk action")
    return
  }

  if (selectedIds.length === 0) {
    alert("Please select at least one registration")
    return
  }

  if (
    action === "delete" &&
    !confirm("Are you sure you want to delete the selected registrations? This action cannot be undone.")
  ) {
    return
  }

  // Process bulk action
  jQuery.ajax({
    url: rubberking_admin_ajax.ajax_url,
    type: "POST",
    data: {
      action: "bulk_action_registrations",
      bulk_action: action,
      registration_ids: selectedIds,
      nonce: rubberking_admin_ajax.nonce,
    },
    success: (response) => {
      if (response.success) {
        location.reload()
      } else {
        alert("Failed to perform bulk action")
      }
    },
    error: () => {
      alert("Network error occurred")
    },
  })
}

function showNotice(message, type) {
  const noticeClass = type === "success" ? "notice-success" : "notice-error"
  const notice = jQuery(`<div class="notice ${noticeClass} is-dismissible"><p>${message}</p></div>`)

  jQuery(".wrap h1").after(notice)

  setTimeout(() => {
    notice.fadeOut()
  }, 3000)
}
