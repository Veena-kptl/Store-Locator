"use client"

import  from "../assets/js/admin"

export default function SyntheticV0PageForDeployment() {
  return < />
}