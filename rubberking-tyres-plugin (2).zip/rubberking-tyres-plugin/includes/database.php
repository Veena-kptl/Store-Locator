<?php
if (!defined('ABSPATH')) {
    exit;
}

class RubberKing_Database {
    
    public function __construct() {
        // Constructor can be used for hooks if needed
    }
    
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Main registrations table
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            customer_name varchar(255) NOT NULL,
            phone_number varchar(20) NOT NULL,
            email varchar(255),
            address text NOT NULL,
            city varchar(100) NOT NULL,
            pincode varchar(10) NOT NULL,
            state varchar(100) NOT NULL,
            tyre_size varchar(50) NOT NULL,
            tyre_size_other varchar(100),
            tyre_brand varchar(100) NOT NULL,
            tyre_brand_other varchar(100),
            number_of_tyres int NOT NULL,
            payment_mode varchar(20) NOT NULL,
            account_holder_name varchar(255),
            bank_account_number varchar(50),
            bank_name varchar(255),
            ifsc_code varchar(20),
            upi_id varchar(100),
            upi_name varchar(255),
            comments text,
            id_card_file varchar(255),
            invoice_file varchar(255) NOT NULL,
            declaration_accepted tinyint(1) NOT NULL DEFAULT 0,
            submission_date datetime DEFAULT CURRENT_TIMESTAMP,
            status varchar(20) DEFAULT 'pending',
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Create uploads directory
        $upload_dir = wp_upload_dir();
        $rubberking_dir = $upload_dir['basedir'] . '/rubberking-registrations';
        
        if (!file_exists($rubberking_dir)) {
            wp_mkdir_p($rubberking_dir);
            
            // Create .htaccess file to protect uploads
            $htaccess_content = "Options -Indexes\n<Files *.php>\nDeny from all\n</Files>";
            file_put_contents($rubberking_dir . '/.htaccess', $htaccess_content);
        }
    }
    
    public static function insert_registration($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        
        $result = $wpdb->insert(
            $table_name,
            $data,
            array(
                '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s',
                '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s',
                '%s', '%s', '%s', '%d'
            )
        );
        
        if ($result === false) {
            return false;
        }
        
        return $wpdb->insert_id;
    }
    
    public static function get_registrations($limit = 20, $offset = 0) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        
        $sql = $wpdb->prepare(
            "SELECT * FROM $table_name ORDER BY submission_date DESC LIMIT %d OFFSET %d",
            $limit,
            $offset
        );
        
        return $wpdb->get_results($sql);
    }
    
    public static function get_registration_by_id($id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        
        $sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id);
        
        return $wpdb->get_row($sql);
    }
    
    public static function update_registration_status($id, $status) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        
        return $wpdb->update(
            $table_name,
            array('status' => $status),
            array('id' => $id),
            array('%s'),
            array('%d')
        );
    }
}
