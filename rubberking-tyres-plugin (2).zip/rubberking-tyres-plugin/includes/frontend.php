<?php
if (!defined('ABSPATH')) {
    exit;
}

class RubberKing_Frontend {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('rubberking_registration_form', array($this, 'display_registration_form'));
        add_action('wp_ajax_submit_rubberking_registration', array($this, 'handle_form_submission'));
        add_action('wp_ajax_nopriv_submit_rubberking_registration', array($this, 'handle_form_submission'));
        
        // Initialize file handler
        require_once RUBBERKING_PLUGIN_PATH . 'includes/file-handler.php';
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_script('rubberking-frontend', RUBBERKING_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), RUBBERKING_VERSION, true);
        wp_enqueue_style('rubberking-frontend', RUBBERKING_PLUGIN_URL . 'assets/css/frontend.css', array(), RUBBERKING_VERSION);
        
        // Localize script for AJAX
        wp_localize_script('rubberking-frontend', 'rubberking_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rubberking_nonce')
        ));
    }
    
    public function display_registration_form($atts) {
        $atts = shortcode_atts(array(
            'title' => 'RubberKing Tyres Promotional Item Registration Form'
        ), $atts);
        
        ob_start();
        ?>
        <div id="rubberking-registration-form" class="rubberking-form-container">
            <div class="rubberking-header">
                <h2><?php echo esc_html($atts['title']); ?></h2>
            </div>
            
            <form id="rubberking-form" method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('rubberking_nonce', 'rubberking_nonce_field'); ?>
                
                <p class="rubberking-intro">
                    Dear Customer, Thank you for purchasing RubberKing Tyres. This form is to register your purchase and collect details for our records and for processing any applicable Cashback and Gift Hamper. Please fill in the details accurately. This form should take about 2 minutes to complete. All your information will be kept confidential and used only for official purposes.
                </p>
                <!-- Section 1: Customer Personal Details -->
                <div class="rubberking-section" data-section="1">
                    <h3 class="section-title">Section 1 of 8: Customer's Personal Details</h3>
                    <p class="section-description">This section collects the basic contact information.</p>
                    <div class="form-row">
						<div class="form-group">
							<label for="customer_name">Customer Name (As Per Invoice) <span class="required">*</span></label>
							<input type="text" id="customer_name" name="customer_name" required>
						</div>
						
						<div class="form-group">
							<label for="phone_number">Phone Number <span class="required">*</span></label>
							<input type="tel" id="phone_number" name="phone_number" required maxlength="10" pattern="[0-9]{10}">
							<small>Please provide your 10-digit mobile number without ISD Code (+91 or 0).</small>
						</div>
					</div>
                    
					<div class="form-row">
						<div class="form-group">
							<label for="id_card_file">ID Card / Photo Identity</label>
							<input type="file" id="id_card_file" name="id_card_file" accept=".jpg,.jpeg,.png,.pdf">
							<small>e.g., Aadhaar Card, PAN Card, Driving License, etc.</small>
						</div>
						
						<div class="form-group">
							<label for="email">Email Address</label>
							<input type="email" id="email" name="email">
						</div>
					</div>
                    
                    <div class="form-group">
                        <label for="address">Full Address to receive the Gift Hamper <span class="required">*</span></label>
                        <textarea id="address" name="address" required rows="3"></textarea>
                        <small>Please provide your complete address including house number, street, and District.</small>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="city">City/Town <span class="required">*</span></label>
                            <input type="text" id="city" name="city" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="pincode">Pincode <span class="required">*</span></label>
                            <input type="text" id="pincode" name="pincode" required pattern="[0-9]{6}" maxlength="6">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="state">State or Union Territory <span class="required">*</span></label>
                        <select id="state" name="state" required>
                            <option value="">Select State</option>
                            <?php
                            $states = get_option('rubberking_states', array());
                            foreach ($states as $state) {
                                echo '<option value="' . esc_attr($state) . '">' . esc_html($state) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                
                <!-- Section 2: Tyre Details -->
                <div class="rubberking-section" data-section="2">
                    <h3 class="section-title">Section 2 of 8: Tyre Details</h3>
                    <div class="form-row">
						<div class="form-group">
							<label for="tyre_size">Tyre Size <span class="required">*</span></label>
							<select id="tyre_size" name="tyre_size" required>
								<option value="">Select Tyre Size</option>
								<?php
								$tyre_sizes = get_option('rubberking_tyre_sizes', array());
								foreach ($tyre_sizes as $size) {
									echo '<option value="' . esc_attr($size) . '">' . esc_html($size) . '</option>';
								}
								?>
								<option value="other">Other</option>
							</select>
						</div>
						
						<div class="form-group" id="tyre_size_other_group" style="display: none;">
							<label for="tyre_size_other">Please specify Tyre Size</label>
							<input type="text" id="tyre_size_other" name="tyre_size_other">
						</div>
					</div>
                    <div class="form-row">
						<div class="form-group">
							<label for="tyre_brand">Tyre Brand <span class="required">*</span></label>
							<select id="tyre_brand" name="tyre_brand" required>
								<option value="">Select Tyre Brand</option>
								<?php
								$tyre_brands = get_option('rubberking_tyre_brands', array());
								foreach ($tyre_brands as $brand) {
									echo '<option value="' . esc_attr($brand) . '">' . esc_html($brand) . '</option>';
								}
								?>
								<option value="other">Other</option>
							</select>
						</div>
                    
						<div class="form-group" id="tyre_brand_other_group" style="display: none;">
							<label for="tyre_brand_other">Please specify Tyre Brand</label>
							<input type="text" id="tyre_brand_other" name="tyre_brand_other">
						</div>
					</div>
                    
                    <div class="form-group">
                        <label for="number_of_tyres">Number of Tyres <span class="required">*</span></label>
                        <input type="number" id="number_of_tyres" name="number_of_tyres" required min="1">
                    </div>
                </div>
                
                <!-- Section 3: Proof of Purchase -->
                <div class="rubberking-section" data-section="3" >
                    <h3 class="section-title">Section 3 of 8: Proof of Purchase</h3>
                    <p class="section-description">
                        This is crucial for verification. Without this, you will not be eligible for any Gifts and Promotional item. Please attach a clear physical copy of the invoice/bill. Ensure the date, dealer name, and tyre details are clearly visible.
                    </p>
                    
                    <div class="form-group">
                        <label for="invoice_file">Upload Invoice/Bill <span class="required">*</span></label>
                        <input type="file" id="invoice_file" name="invoice_file" required accept=".jpg,.jpeg,.png,.pdf">
                    </div>
                </div>
                
                <!-- Section 4: Payment Details -->
                <div class="rubberking-section" data-section="4">
                    <h3 class="section-title">Section 4 of 8: Payment Details (For Cashback / Rewards)</h3>
                    <p class="section-description">
                        <strong>IMPORTANT!!</strong> Please double-check all details for accuracy. RubberKing Tyres will not be responsible for payments made to an incorrect account due to wrong information.
                    </p>
                    
                    <div class="form-group">
                        <label>Preferred Mode of Payment <span class="required">*</span></label>
                        <div class="radio-group">
                            <label class="radio-label">
                                <input type="radio" name="payment_mode" value="bank_transfer" required>
                                Bank Transfer
                            </label>
                            <label class="radio-label">
                                <input type="radio" name="payment_mode" value="upi" required>
                                UPI
                            </label>
                        </div>
                    </div>
                </div>
                
                <!-- Section 5: Bank Account Details -->
                <div class="rubberking-section bank-details" data-section="5" >
                    <h3 class="section-title">Section 5 of 8: Bank Account Details</h3>
                    <div class="form-row">
						<div class="form-group">
							<label for="account_holder_name">Account Holder Name <span class="required">*</span></label>
							<input type="text" id="account_holder_name" name="account_holder_name">
							<small>Name as it appears in your bank passbook.</small>
						</div>
						
						<div class="form-group">
							<label for="bank_account_number">Bank Account Number <span class="required">*</span></label>
							<input type="text" id="bank_account_number" name="bank_account_number" onkeypress="return isNumberKey(event)" pattern="[0-9]{9,18}" title="Please enter a valid bank account number (9-18 digits)">
						</div>
					</div>
                    <div class="form-row">
						<div class="form-group">
							<label for="bank_name">Bank Name <span class="required">*</span></label>
							<input type="text" id="bank_name" name="bank_name" placeholder="e.g., State Bank of India">
						</div>
						
						<div class="form-group">
							<label for="ifsc_code">IFSC Code <span class="required">*</span></label>
							<input type="text" id="ifsc_code" name="ifsc_code" maxlength="11">
							<small>An 11-character code found on your cheque book or passbook.</small>
						</div>
					</div>
                </div>
                
                <!-- Section 6: UPI Details -->
                <div class="rubberking-section upi-details" data-section="6">
                    <h3 class="section-title">Section 6 of 8: UPI Details</h3>
                    <div class="form-row">
						<div class="form-group">
							<label for="upi_id">UPI ID (VPA) <span class="required">*</span></label>
							<input type="text" id="upi_id" name="upi_id" placeholder="e.g., yourname@oksbi or 9876543210@paytm">
						</div>
						
						<div class="form-group">
							<label for="upi_name">Name associated with UPI ID <span class="required">*</span></label>
							<input type="text" id="upi_name" name="upi_name">
						</div>
					</div>
                </div>
                
                <!-- Section 7: Final Confirmation -->
                <div class="rubberking-section" data-section="7">
                    <h3 class="section-title">Section 7 of 8: Final Confirmation</h3>
                    
                    <div class="form-group">
                        <label for="comments">Any other comments or feedback?</label>
                        <textarea id="comments" name="comments" rows="4"></textarea>
                    </div>
                    
                </div>
                
                <!-- Section 8: Declaration -->
                <div class="rubberking-section" data-section="8">
                    <h3 class="section-title">Section 8 of 8: Declaration</h3>
                    
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="declaration_accepted" value="1" required>
                            I hereby declare that the information provided above is true and correct to the best of my knowledge.
                        </label>
                    </div>
                    
                    <div class="form-navigation">
                        <button type="submit" class="btn-submit">Submit Registration</button>
                    </div>
                </div>
            </form>
            
            <div id="rubberking-success-message" style="display: none;">
                <!-- Success message will be loaded here -->
            </div>
        </div>
		<script>
			function isNumberKey(evt) {
			  var charCode = (evt.which) ? evt.which : evt.keyCode
			  if (charCode > 31 && (charCode < 48 || charCode > 57))
				return false;
			  return true;
			}
		</script>
        <?php
        return ob_get_clean();
    }
    
    public function handle_form_submission() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['rubberking_nonce_field'], 'rubberking_nonce')) {
            wp_die('Security check failed');
        }
        
        $file_handler = new RubberKing_File_Handler();
        
        // Handle file uploads
        $id_card_file = '';
        $invoice_file = '';
        
        if (!empty($_FILES['id_card_file']['name'])) {
            $upload_result = $file_handler->handle_file_upload('id_card_file');
            if (is_array($upload_result) && isset($upload_result['error'])) {
                wp_send_json_error($upload_result['error']);
                return;
            }
            $id_card_file = $upload_result;
        }
        
        if (!empty($_FILES['invoice_file']['name'])) {
            $upload_result = $file_handler->handle_file_upload('invoice_file');
            if (is_array($upload_result) && isset($upload_result['error'])) {
                wp_send_json_error($upload_result['error']);
                return;
            }
            $invoice_file = $upload_result;
        } else {
            wp_send_json_error('Invoice file is required.');
            return;
        }
        
        // Prepare data for database
        $data = array(
            'customer_name' => sanitize_text_field($_POST['customer_name']),
            'phone_number' => sanitize_text_field($_POST['phone_number']),
            'email' => sanitize_email($_POST['email']),
            'address' => sanitize_textarea_field($_POST['address']),
            'city' => sanitize_text_field($_POST['city']),
            'pincode' => sanitize_text_field($_POST['pincode']),
            'state' => sanitize_text_field($_POST['state']),
            'tyre_size' => sanitize_text_field($_POST['tyre_size']),
            'tyre_size_other' => sanitize_text_field($_POST['tyre_size_other']),
            'tyre_brand' => sanitize_text_field($_POST['tyre_brand']),
            'tyre_brand_other' => sanitize_text_field($_POST['tyre_brand_other']),
            'number_of_tyres' => intval($_POST['number_of_tyres']),
            'payment_mode' => $_POST['payment_mode'],
            'account_holder_name' => sanitize_text_field($_POST['account_holder_name']),
            'bank_account_number' => sanitize_text_field($_POST['bank_account_number']),
            'bank_name' => sanitize_text_field($_POST['bank_name']),
            'ifsc_code' => sanitize_text_field($_POST['ifsc_code']),
            'upi_id' => sanitize_text_field($_POST['upi_id']),
            'upi_name' => sanitize_text_field($_POST['upi_name']),
            'comments' => sanitize_textarea_field($_POST['comments']),
            'id_card_file' => $id_card_file,
            'invoice_file' => $invoice_file,
            'declaration_accepted' => intval($_POST['declaration_accepted'])
        );
        
        // Insert into database
        $registration_id = RubberKing_Database::insert_registration($data);
        
        if ($registration_id) {
            // Update file names with registration ID for better organization
            if ($id_card_file) {
                $new_id_card_file = $file_handler->handle_file_upload('id_card_file', $registration_id);
                if ($new_id_card_file && !is_array($new_id_card_file)) {
                    // Update database with new filename
                    global $wpdb;
                    $table_name = $wpdb->prefix . 'rubberking_registrations';
                    $wpdb->update(
                        $table_name,
                        array('id_card_file' => $new_id_card_file),
                        array('id' => $registration_id),
                        array('%s'),
                        array('%d')
                    );
                    
                    // Delete old file
                    $file_handler->delete_file($id_card_file);
                    $id_card_file = $new_id_card_file;
                }
            }
            
            if ($invoice_file) {
                $new_invoice_file = $file_handler->handle_file_upload('invoice_file', $registration_id);
                if ($new_invoice_file && !is_array($new_invoice_file)) {
                    // Update database with new filename
                    global $wpdb;
                    $table_name = $wpdb->prefix . 'rubberking_registrations';
                    $wpdb->update(
                        $table_name,
                        array('invoice_file' => $new_invoice_file),
                        array('id' => $registration_id),
                        array('%s'),
                        array('%d')
                    );
                    
                    // Delete old file
                    $file_handler->delete_file($invoice_file);
                    $invoice_file = $new_invoice_file;
                }
            }
            
            // Send email notification
            $email_handler = new RubberKing_Email_Handler();
            $email_handler->send_registration_email($data, $registration_id);
            
            // Get success message
            $success_message = get_option('rubberking_success_message', 'Thank you for your registration!');
            
            wp_send_json_success(array(
                'message' => $success_message,
                'registration_id' => $registration_id
            ));
        } else {
            // Clean up uploaded files if database insertion failed
            if ($id_card_file) {
                $file_handler->delete_file($id_card_file);
            }
            if ($invoice_file) {
                $file_handler->delete_file($invoice_file);
            }
            
            wp_send_json_error('Registration failed. Please try again.');
        }
    }
    
    private function handle_file_upload($file_key) {
        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        
        $uploadedfile = $_FILES[$file_key];
        
        // Custom upload directory
        $upload_dir = wp_upload_dir();
        $custom_dir = $upload_dir['basedir'] . '/rubberking-registrations';
        
        if (!file_exists($custom_dir)) {
            wp_mkdir_p($custom_dir);
        }
        
        $upload_overrides = array(
            'test_form' => false,
            'upload_path' => $custom_dir
        );
        
        $movefile = wp_handle_upload($uploadedfile, $upload_overrides);
        
        if ($movefile && !isset($movefile['error'])) {
            return basename($movefile['file']);
        }
        
        return false;
    }
}
