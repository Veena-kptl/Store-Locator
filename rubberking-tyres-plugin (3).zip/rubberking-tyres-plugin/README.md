# RubberKing Tyres Registration Plugin

A comprehensive WordPress plugin for managing tyre registration forms with promotional item processing and cashback management.

## Features

- **Multi-Section Registration Form**: 8-step form with progress indicator
- **File Upload System**: Secure handling of ID cards and invoice documents
- **Admin Dashboard**: Complete management interface for registrations
- **Email Notifications**: Customizable email templates for customers
- **Dropdown Management**: Editable options for states, tyre sizes, and brands
- **Export Functionality**: CSV export of all registrations
- **Status Management**: Track registration status (pending, approved, rejected)
- **Responsive Design**: Mobile-friendly interface
- **Security Features**: File validation, nonce protection, and sanitized inputs

## Installation

### Method 1: Upload Plugin Files

1. Download the plugin files
2. Upload the `rubberking-tyres-registration` folder to `/wp-content/plugins/`
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Navigate to 'RubberKing Tyres' in the admin menu to configure settings

### Method 2: WordPress Admin Upload

1. Go to Plugins > Add New in your WordPress admin
2. Click "Upload Plugin"
3. Choose the plugin ZIP file and click "Install Now"
4. Activate the plugin

## Usage

### Displaying the Registration Form

Use the shortcode `[rubberking_registration_form]` to display the form on any page or post.

**Example:**
\`\`\`
[rubberking_registration_form title="Register Your Tyre Purchase"]
\`\`\`

### Admin Management

#### Viewing Registrations
- Navigate to **RubberKing Tyres > All Registrations**
- View detailed registration information
- Update registration status
- Export data to CSV
- Bulk actions for multiple registrations

#### Settings Configuration
- Go to **RubberKing Tyres > Settings**
- Customize success message shown after form submission
- Edit email template sent to customers
- Available placeholders: `{customer_name}`, `{phone_number}`, `{email}`, `{address}`, `{city}`, `{pincode}`, `{state}`, `{tyre_size}`, `{tyre_brand}`, `{number_of_tyres}`, `{payment_mode}`, `{registration_id}`, `{date}`

#### Dropdown Options Management
- Access **RubberKing Tyres > Dropdown Options**
- Add/remove states and union territories
- Manage tyre sizes list
- Update tyre brands list

## Form Sections

### Section 1: Customer Personal Details
- Customer name (required)
- Phone number (required, 10 digits)
- ID card upload (optional)
- Email address (optional)
- Full address (required)
- City/Town (required)
- Pincode (required, 6 digits)
- State selection (required)

### Section 2: Tyre Details
- Tyre size selection with "Other" option
- Tyre brand selection with "Other" option
- Number of tyres (required)

### Section 3: Proof of Purchase
- Invoice/bill upload (required)
- Supports JPG, PNG, PDF files up to 5MB

### Section 4: Payment Details
- Payment mode selection (Bank Transfer or UPI)

### Section 5: Bank Account Details
- Account holder name
- Bank account number
- Bank name
- IFSC code

### Section 6: UPI Details
- UPI ID/VPA
- Name associated with UPI ID

### Section 7: Final Confirmation
- Comments/feedback (optional)

### Section 8: Declaration
- Acceptance of terms and conditions

## File Security

- Files are stored in `/wp-content/uploads/rubberking-registrations/`
- Protected directory with `.htaccess` restrictions
- File type validation (JPG, PNG, PDF only)
- File size limit (5MB maximum)
- Unique filename generation to prevent conflicts
- Automatic cleanup of orphaned files

## Database Structure

The plugin creates a table `wp_rubberking_registrations` with the following fields:

- Customer information (name, phone, email, address)
- Tyre details (size, brand, quantity)
- Payment information (mode, bank details, UPI details)
- File references (ID card, invoice)
- Status tracking and timestamps

## Email System

- Automatic email notifications to customers upon successful registration
- Customizable email templates with placeholder support
- HTML email format with proper headers
- Admin can edit email content and success messages

## Security Features

- WordPress nonce verification for all forms
- File upload validation and sanitization
- SQL injection prevention with prepared statements
- XSS protection with proper escaping
- User capability checks for admin functions
- Secure file download system for admin users

## Customization

### Styling
- Modify `/assets/css/frontend.css` for form appearance
- Edit `/assets/css/admin.css` for admin interface styling
- Responsive design with mobile-first approach

### Functionality
- Extend form fields by modifying the database schema
- Add custom validation rules in the JavaScript files
- Implement additional email templates or notifications

## Troubleshooting

### Common Issues

**Form not displaying:**
- Ensure the shortcode is correctly placed
- Check if the plugin is activated
- Verify there are no JavaScript errors in browser console

**File uploads failing:**
- Check PHP upload limits (`upload_max_filesize`, `post_max_size`)
- Ensure `/wp-content/uploads/` directory is writable
- Verify file types are allowed (JPG, PNG, PDF only)

**Emails not sending:**
- Check WordPress email configuration
- Verify SMTP settings if using custom email setup
- Test with a simple email plugin to confirm email functionality

**Admin pages not loading:**
- Check user permissions (requires `manage_options` capability)
- Clear any caching plugins
- Check for plugin conflicts by deactivating other plugins

### File Permissions
Ensure the following directories are writable:
- `/wp-content/uploads/`
- `/wp-content/uploads/rubberking-registrations/`

### PHP Requirements
- PHP 7.4 or higher
- WordPress 5.0 or higher
- MySQL 5.6 or higher

## Support

For technical support or feature requests, please contact:
- Email: support@rubberkingtyres.com
- Phone: [Your Support Number]

## Changelog

### Version 1.0.0
- Initial release
- Multi-section registration form
- Admin dashboard with full management capabilities
- File upload system with security features
- Email notification system
- Export functionality
- Responsive design

## License

This plugin is licensed under the GPL v2 or later.

## Credits

Developed for RubberKing Tyres promotional registration system.
