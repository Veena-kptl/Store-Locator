<?php
if (!defined('ABSPATH')) {
    exit;
}

class RubberKing_Admin {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_update_rubberking_options', array($this, 'handle_options_update'));
        add_action('wp_ajax_delete_registration', array($this, 'handle_delete_registration'));
        add_action('wp_ajax_update_registration_status', array($this, 'handle_status_update'));
        add_action('wp_ajax_export_registrations', array($this, 'handle_export_registrations'));
        add_action('wp_ajax_get_registration_details', array($this, 'handle_get_registration_details'));
        add_action('wp_ajax_bulk_action_registrations', array($this, 'handle_bulk_actions'));
        
        // Schedule cleanup of orphaned files
        if (!wp_next_scheduled('rubberking_cleanup_files')) {
            wp_schedule_event(time(), 'daily', 'rubberking_cleanup_files');
        }
        add_action('rubberking_cleanup_files', array('RubberKing_File_Handler', 'cleanup_orphaned_files'));
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'RubberKing Registrations',
            'RubberKing Tyres',
            'manage_options',
            'rubberking-registrations',
            array($this, 'admin_page'),
            'dashicons-clipboard',
            30
        );
        
        add_submenu_page(
            'rubberking-registrations',
            'All Registrations',
            'All Registrations',
            'manage_options',
            'rubberking-registrations',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'rubberking-registrations',
            'Settings',
            'Settings',
            'manage_options',
            'rubberking-settings',
            array($this, 'settings_page')
        );
        
        add_submenu_page(
            'rubberking-registrations',
            'Dropdown Options',
            'Dropdown Options',
            'manage_options',
            'rubberking-dropdowns',
            array($this, 'dropdowns_page')
        );
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'rubberking') !== false) {
            wp_enqueue_script('rubberking-admin', RUBBERKING_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), RUBBERKING_VERSION, true);
            wp_enqueue_style('rubberking-admin', RUBBERKING_PLUGIN_URL . 'assets/css/admin.css', array(), RUBBERKING_VERSION);
            
            wp_localize_script('rubberking-admin', 'rubberking_admin_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('rubberking_admin_nonce')
            ));
        }
    }
    
    public function admin_page() {
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = 20;
        $offset = ($page - 1) * $per_page;
        
        $registrations = RubberKing_Database::get_registrations($per_page, $offset);
        $total_registrations = $this->get_total_registrations();
        $total_pages = ceil($total_registrations / $per_page);
        
        ?>
        <div class="wrap">
            <h1>RubberKing Tyre Registrations</h1>
            
            <div class="rubberking-admin-stats">
                <div class="stat-box">
                    <h3><?php echo $total_registrations; ?></h3>
                    <p>Total Registrations</p>
                </div>
                <div class="stat-box">
                    <h3><?php echo $this->get_registrations_count_by_status('pending'); ?></h3>
                    <p>Pending</p>
                </div>
                <div class="stat-box">
                    <h3><?php echo $this->get_registrations_count_by_status('approved'); ?></h3>
                    <p>Approved</p>
                </div>
                <div class="stat-box">
                    <h3><?php echo $this->get_registrations_count_by_status('rejected'); ?></h3>
                    <p>Rejected</p>
                </div>
            </div>
            
            <div class="rubberking-admin-actions">
                <button class="button button-primary" onclick="exportRegistrations()">Export to CSV</button>
                <select id="bulk-action">
                    <option value="">Bulk Actions</option>
                    <option value="approved">Approve</option>
                    <option value="rejected">Reject</option>
                    <option value="pending">Mark as Pending</option>
                    <option value="delete">Delete</option>
                </select>
                <button class="button" onclick="applyBulkAction()">Apply</button>
            </div>
            
            <?php if (empty($registrations)): ?>
                <div class="notice notice-info">
                    <p>No registrations found.</p>
                </div>
            <?php else: ?>
                <form id="registrations-form">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <td class="manage-column column-cb check-column">
                                    <input type="checkbox" id="select-all">
                                </td>
                                <th>ID</th>
                                <th>Customer Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Tyre Details</th>
                                <th>Payment Mode</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($registrations as $registration): ?>
                                <tr>
                                    <th class="check-column">
                                        <input type="checkbox" name="registration_ids[]" value="<?php echo $registration->id; ?>">
                                    </th>
                                    <td><?php echo $registration->id; ?></td>
                                    <td><strong><?php echo esc_html($registration->customer_name); ?></strong></td>
                                    <td><?php echo esc_html($registration->phone_number); ?></td>
                                    <td><?php echo esc_html($registration->email); ?></td>
                                    <td>
                                        <?php 
                                        $tyre_size = $registration->tyre_size === 'other' ? $registration->tyre_size_other : $registration->tyre_size;
                                        $tyre_brand = $registration->tyre_brand === 'other' ? $registration->tyre_brand_other : $registration->tyre_brand;
                                        echo esc_html($tyre_brand . ' - ' . $tyre_size . ' (' . $registration->number_of_tyres . ')');
                                        ?>
                                    </td>
                                    <td><?php echo esc_html(ucfirst(str_replace('_', ' ', $registration->payment_mode))); ?></td>
                                    <td>
                                        <select class="status-select" data-id="<?php echo $registration->id; ?>">
                                            <option value="pending" <?php selected($registration->status, 'pending'); ?>>Pending</option>
                                            <option value="approved" <?php selected($registration->status, 'approved'); ?>>Approved</option>
                                            <option value="rejected" <?php selected($registration->status, 'rejected'); ?>>Rejected</option>
                                        </select>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($registration->submission_date)); ?></td>
                                    <td>
                                        <button class="button button-small" onclick="viewRegistration(<?php echo $registration->id; ?>)">View</button>
                                        <button class="button button-small button-link-delete" onclick="deleteRegistration(<?php echo $registration->id; ?>)">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </form>
                
                <?php if ($total_pages > 1): ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $page
                            ));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        
        <!-- Registration Details Modal -->
        <div id="registration-modal" class="rubberking-modal" style="display: none;">
            <div class="rubberking-modal-content">
                <span class="rubberking-modal-close">&times;</span>
                <div id="registration-details"></div>
            </div>
        </div>
        <?php
    }
    
    public function settings_page() {
        if (isset($_POST['submit'])) {
            $this->save_settings();
        }
        
        $success_message = get_option('rubberking_success_message', '');
        $email_template = get_option('rubberking_email_template', '');
		$email_id = get_option('rubberking_email_id', '');
		if(function_exists( 'wp_enqueue_media' )){
			wp_enqueue_media();
		}else{
			wp_enqueue_style('thickbox');
			wp_enqueue_script('media-upload');
			wp_enqueue_script('thickbox');
		}
        ?>
        <div class="wrap">
            <h1>RubberKing Settings</h1>
            
            <form method="post" action="" enctype="multipart/form-data">
                <?php wp_nonce_field('rubberking_settings_nonce', 'rubberking_settings_nonce_field'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Success Message</th>
                        <td>
                            <textarea name="success_message" rows="5" cols="50" class="large-text"><?php echo esc_textarea($success_message); ?></textarea>
                            <p class="description">Message displayed to users after successful form submission.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Email Template</th>
                        <td>
                            <textarea name="email_template" rows="10" cols="50" class="large-text"><?php echo esc_textarea($email_template); ?></textarea>
                            <p class="description">
                                Email template sent to customers. Available placeholders: 
                                {customer_name}, {phone_number}, {email}, {address}, {city}, {pincode}, {state}, 
                                {tyre_size}, {tyre_brand}, {number_of_tyres}, {payment_mode}, {registration_id}, {date}
                            </p>
                        </td>
                    </tr>
					<tr>
                        <th scope="row">Email Address</th>
                        <td>
                            <input type="text" name="email_id" rows="5" cols="50" class="large-text" value="<?php echo esc_attr($email_id); ?>" >
                            <p class="description">Email </p>
                        </td>
                    </tr>
					<tr>
						<th scope="row">Header Logo Image URL:</th>
						<td>
							
							<img class="header_logo" src="<?php echo get_option('header_logo'); ?>" height="100" width="100"/>
							<input class="header_logo_url" type="file" name="header_logo" size="60" value="<?php echo get_option('header_logo'); ?>">
						</td>
					</tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    public function dropdowns_page() {
        if (isset($_POST['submit'])) {
            $this->save_dropdown_options();
        }
        
        $states = get_option('rubberking_states', array());
        $tyre_sizes = get_option('rubberking_tyre_sizes', array());
        $tyre_brands = get_option('rubberking_tyre_brands', array());
        ?>
        <div class="wrap">
            <h1>Dropdown Options Management</h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('rubberking_dropdowns_nonce', 'rubberking_dropdowns_nonce_field'); ?>
                
                <div class="rubberking-dropdown-section">
                    <h2>States/Union Territories</h2>
                    <div class="dropdown-manager" data-type="states">
                        <div class="dropdown-items">
                            <?php foreach ($states as $index => $state): ?>
                                <div class="dropdown-item">
                                    <input type="text" name="states[]" value="<?php echo esc_attr($state); ?>">
                                    <button type="button" class="button remove-item">Remove</button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="button add-item">Add State</button>
                    </div>
                </div>
                
                <div class="rubberking-dropdown-section">
                    <h2>Tyre Sizes</h2>
                    <div class="dropdown-manager" data-type="tyre_sizes">
                        <div class="dropdown-items">
                            <?php foreach ($tyre_sizes as $index => $size): ?>
                                <div class="dropdown-item">
                                    <input type="text" name="tyre_sizes[]" value="<?php echo esc_attr($size); ?>">
                                    <button type="button" class="button remove-item">Remove</button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="button add-item">Add Size</button>
                    </div>
                </div>
                
                <div class="rubberking-dropdown-section">
                    <h2>Tyre Brands</h2>
                    <div class="dropdown-manager" data-type="tyre_brands">
                        <div class="dropdown-items">
                            <?php foreach ($tyre_brands as $index => $brand): ?>
                                <div class="dropdown-item">
                                    <input type="text" name="tyre_brands[]" value="<?php echo esc_attr($brand); ?>">
                                    <button type="button" class="button remove-item">Remove</button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="button add-item">Add Brand</button>
                    </div>
                </div>
                
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    private function save_settings() {
        if (!wp_verify_nonce($_POST['rubberking_settings_nonce_field'], 'rubberking_settings_nonce')) {
            wp_die('Security check failed');
        }
        
        update_option('rubberking_success_message', sanitize_textarea_field($_POST['success_message']));
        update_option('rubberking_email_template', sanitize_textarea_field($_POST['email_template']));
		update_option('rubberking_email_id', sanitize_text_field($_POST['email_id']));
  
		if($_FILES['header_logo']['name']) {
		  if(!$_FILES['header_logo']['error']) {
			//validate the file
			$new_file_name = strtolower($_FILES['header_logo']['tmp_name']);
			
			  //the file has passed the test
			  //These files need to be included as dependencies when on the front end.
			  require_once( ABSPATH . 'wp-admin/includes/image.php' );
			  require_once( ABSPATH . 'wp-admin/includes/file.php' );
			  require_once( ABSPATH . 'wp-admin/includes/media.php' );
			   
			  // Let WordPress handle the upload.
			  // Remember, 'upload' is the name of our file input in our form above.
			  $file_id = media_handle_upload( 'header_logo', 0 );
			   $upload_dir = wp_upload_dir();
			  update_option('rubberking_header_logo', $upload_dir['url'].sanitize_text_field($_FILES['header_logo']['name']));
			
		  }
		}
				
				echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
	}
    
    private function save_dropdown_options() {
        if (!wp_verify_nonce($_POST['rubberking_dropdowns_nonce_field'], 'rubberking_dropdowns_nonce')) {
            wp_die('Security check failed');
        }
        
        $states = array_filter(array_map('sanitize_text_field', $_POST['states']));
        $tyre_sizes = array_filter(array_map('sanitize_text_field', $_POST['tyre_sizes']));
        $tyre_brands = array_filter(array_map('sanitize_text_field', $_POST['tyre_brands']));
        
        update_option('rubberking_states', $states);
        update_option('rubberking_tyre_sizes', $tyre_sizes);
        update_option('rubberking_tyre_brands', $tyre_brands);
        
        echo '<div class="notice notice-success"><p>Dropdown options saved successfully!</p></div>';
    }
    
    public function handle_status_update() {
        if (!wp_verify_nonce($_POST['nonce'], 'rubberking_admin_nonce')) {
            wp_die('Security check failed');
        }
        
        $registration_id = intval($_POST['registration_id']);
        $status = sanitize_text_field($_POST['status']);
        
        $result = RubberKing_Database::update_registration_status($registration_id, $status);
        
        if ($result !== false) {
            wp_send_json_success('Status updated successfully');
        } else {
            wp_send_json_error('Failed to update status');
        }
    }
    
    public function handle_delete_registration() {
        if (!wp_verify_nonce($_POST['nonce'], 'rubberking_admin_nonce')) {
            wp_die('Security check failed');
        }
        
        global $wpdb;
        $registration_id = intval($_POST['registration_id']);
        
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        $result = $wpdb->delete($table_name, array('id' => $registration_id), array('%d'));
        
        if ($result !== false) {
            wp_send_json_success('Registration deleted successfully');
        } else {
            wp_send_json_error('Failed to delete registration');
        }
    }
    
    public function handle_export_registrations() {
        if (!wp_verify_nonce($_POST['nonce'], 'rubberking_admin_nonce')) {
            wp_die('Security check failed');
        }
        
        $registrations = RubberKing_Database::get_registrations(1000, 0); // Get all registrations
        
        $csv_data = array();
        $csv_data[] = array(
            'ID', 'Customer Name', 'Phone', 'Email', 'Address', 'City', 'Pincode', 'State',
            'Tyre Size', 'Tyre Brand', 'Number of Tyres', 'Payment Mode', 'Account Holder',
            'Bank Account', 'Bank Name', 'IFSC', 'UPI ID', 'UPI Name', 'Comments', 'Status', 'Date'
        );
        
        foreach ($registrations as $reg) {
            $csv_data[] = array(
                $reg->id,
                $reg->customer_name,
                $reg->phone_number,
                $reg->email,
                $reg->address,
                $reg->city,
                $reg->pincode,
                $reg->state,
                $reg->tyre_size === 'other' ? $reg->tyre_size_other : $reg->tyre_size,
                $reg->tyre_brand === 'other' ? $reg->tyre_brand_other : $reg->tyre_brand,
                $reg->number_of_tyres,
                $reg->payment_mode,
                $reg->account_holder_name,
                $reg->bank_account_number,
                $reg->bank_name,
                $reg->ifsc_code,
                $reg->upi_id,
                $reg->upi_name,
                $reg->comments,
                $reg->status,
                $reg->submission_date
            );
        }
        
        wp_send_json_success(array('csv_data' => $csv_data));
    }
    
    public function handle_get_registration_details() {
        if (!wp_verify_nonce($_POST['nonce'], 'rubberking_admin_nonce')) {
            wp_die('Security check failed');
        }
        
        $registration_id = intval($_POST['registration_id']);
        $registration = RubberKing_Database::get_registration_by_id($registration_id);
        
        if (!$registration) {
            wp_send_json_error('Registration not found');
            return;
        }
        
        $file_handler = new RubberKing_File_Handler();
        
        ob_start();
        ?>
        <h2>Registration Details - ID: <?php echo $registration->id; ?></h2>
        
        <div class="registration-details-grid">
            <div class="detail-section">
                <h3>Personal Information</h3>
                <div class="registration-detail">
                    <strong>Customer Name:</strong> <?php echo esc_html($registration->customer_name); ?>
                </div>
                <div class="registration-detail">
                    <strong>Phone Number:</strong> <?php echo esc_html($registration->phone_number); ?>
                </div>
                <div class="registration-detail">
                    <strong>Email:</strong> <?php echo esc_html($registration->email ?: 'Not provided'); ?>
                </div>
                <div class="registration-detail">
                    <strong>Address:</strong> <?php echo esc_html($registration->address); ?>
                </div>
                <div class="registration-detail">
                    <strong>City:</strong> <?php echo esc_html($registration->city); ?>
                </div>
                <div class="registration-detail">
                    <strong>Pincode:</strong> <?php echo esc_html($registration->pincode); ?>
                </div>
                <div class="registration-detail">
                    <strong>State:</strong> <?php echo esc_html($registration->state); ?>
                </div>
            </div>
            
            <div class="detail-section">
                <h3>Tyre Information</h3>
                <div class="registration-detail">
                    <strong>Tyre Size:</strong> 
                    <?php echo esc_html($registration->tyre_size === 'other' ? $registration->tyre_size_other : $registration->tyre_size); ?>
                </div>
                <div class="registration-detail">
                    <strong>Tyre Brand:</strong> 
                    <?php echo esc_html($registration->tyre_brand === 'other' ? $registration->tyre_brand_other : $registration->tyre_brand); ?>
                </div>
                <div class="registration-detail">
                    <strong>Number of Tyres:</strong> <?php echo esc_html($registration->number_of_tyres); ?>
                </div>
            </div>
            
            <div class="detail-section">
                <h3>Payment Information</h3>
                <div class="registration-detail">
                    <strong>Payment Mode:</strong> <?php echo esc_html(ucfirst(str_replace('_', ' ', $registration->payment_mode))); ?>
                </div>
                
                <?php if ($registration->payment_mode === 'bank_transfer'): ?>
                    <div class="registration-detail">
                        <strong>Account Holder:</strong> <?php echo esc_html($registration->account_holder_name); ?>
                    </div>
                    <div class="registration-detail">
                        <strong>Account Number:</strong> <?php echo esc_html($registration->bank_account_number); ?>
                    </div>
                    <div class="registration-detail">
                        <strong>Bank Name:</strong> <?php echo esc_html($registration->bank_name); ?>
                    </div>
                    <div class="registration-detail">
                        <strong>IFSC Code:</strong> <?php echo esc_html($registration->ifsc_code); ?>
                    </div>
                <?php elseif ($registration->payment_mode === 'upi'): ?>
                    <div class="registration-detail">
                        <strong>UPI ID:</strong> <?php echo esc_html($registration->upi_id); ?>
                    </div>
                    <div class="registration-detail">
                        <strong>UPI Name:</strong> <?php echo esc_html($registration->upi_name); ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="detail-section">
                <h3>Files & Documents</h3>
                
                <?php if ($registration->id_card_file): ?>
                    <?php $id_card_info = $file_handler->get_file_info($registration->id_card_file); ?>
                    <div class="registration-detail">
                        <strong>ID Card:</strong>
                        <?php if ($id_card_info): ?>
                            <a href="<?php echo esc_url($id_card_info['download_url']); ?>" class="file-link" target="_blank">
                                View ID Card (<?php echo $id_card_info['type']; ?> - <?php echo $id_card_info['size_formatted']; ?>)
                            </a>
                        <?php else: ?>
                            <span class="file-missing">File not found</span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($registration->invoice_file): ?>
                    <?php $invoice_info = $file_handler->get_file_info($registration->invoice_file); ?>
                    <div class="registration-detail">
                        <strong>Invoice:</strong>
                        <?php if ($invoice_info): ?>
                            <a href="<?php echo esc_url($invoice_info['download_url']); ?>" class="file-link" target="_blank">
                                View Invoice (<?php echo $invoice_info['type']; ?> - <?php echo $invoice_info['size_formatted']; ?>)
                            </a>
                        <?php else: ?>
                            <span class="file-missing">File not found</span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="detail-section">
                <h3>Additional Information</h3>
                <div class="registration-detail">
                    <strong>Comments:</strong> <?php echo esc_html($registration->comments ?: 'None'); ?>
                </div>
                <div class="registration-detail">
                    <strong>Status:</strong> 
                    <span class="status-badge status-<?php echo esc_attr($registration->status); ?>">
                        <?php echo esc_html(ucfirst($registration->status)); ?>
                    </span>
                </div>
                <div class="registration-detail">
                    <strong>Submission Date:</strong> <?php echo date('F j, Y g:i A', strtotime($registration->submission_date)); ?>
                </div>
                <div class="registration-detail">
                    <strong>Declaration:</strong> <?php echo $registration->declaration_accepted ? 'Accepted' : 'Not Accepted'; ?>
                </div>
            </div>
        </div>
        <?php
        $html = ob_get_clean();
        
        wp_send_json_success(array('html' => $html));
    }
    
    public function handle_bulk_actions() {
        if (!wp_verify_nonce($_POST['nonce'], 'rubberking_admin_nonce')) {
            wp_die('Security check failed');
        }
        
        $action = sanitize_text_field($_POST['bulk_action']);
        $registration_ids = array_map('intval', $_POST['registration_ids']);
        
        if (empty($registration_ids)) {
            wp_send_json_error('No registrations selected');
            return;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        $success_count = 0;
        
        foreach ($registration_ids as $id) {
            if ($action === 'delete') {
                // Get file names before deleting
                $registration = RubberKing_Database::get_registration_by_id($id);
                if ($registration) {
                    $file_handler = new RubberKing_File_Handler();
                    if ($registration->id_card_file) {
                        $file_handler->delete_file($registration->id_card_file);
                    }
                    if ($registration->invoice_file) {
                        $file_handler->delete_file($registration->invoice_file);
                    }
                }
                
                $result = $wpdb->delete($table_name, array('id' => $id), array('%d'));
            } else {
                // Update status
                $result = RubberKing_Database::update_registration_status($id, $action);
            }
            
            if ($result !== false) {
                $success_count++;
            }
        }
        
        wp_send_json_success(array(
            'message' => "Successfully processed {$success_count} registrations"
        ));
    }
    
    private function get_total_registrations() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    }
    
    private function get_registrations_count_by_status($status) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'rubberking_registrations';
        return $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE status = %s", $status));
    }
}
